//
//  Usuario.swift
//  pomusFocus_PROJETO
//
//  Created by Student on 14/12/22.
//  Copyright © 2022 Student. All rights reserved.
/* caso nao encontrar algumas arquivos, ver neste link: (na duvida, tire isso tbm)
https://drive.google.com/drive/folders/1V4R2pZY_WL4UKT5hyNzikoYtX7kjG99Q?usp=share_link
*/
import Foundation

struct Usuario{
    static var nomeUsuario = "Manuel"
    static var imagemUsuario = "yes"
    static var numeroSessoes = 0
    static var minutosPorSessao = 1
    static var minutosTotal = 0
    static var streak = 28
    static var count = 0
    static var reset:Bool = false
    
    
}
