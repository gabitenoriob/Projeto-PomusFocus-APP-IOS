//
//  PerfilViewController.swift
//  pomusFocus_PROJETO
//
//  Created by Student on 14/12/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class PerfilViewController: UIViewController {
    
    @IBOutlet weak var nomeUsuario: UILabel!
    @IBOutlet weak var usuarioImagem: UIImageView!
    
    @IBOutlet weak var numeroSessoesLabel: UILabel!
    
    @IBOutlet weak var minutosSessaoLabel: UILabel!

    
    @IBOutlet weak var streakLabel: UILabel!
    
    @IBOutlet weak var focoTotalLabel: UILabel!
    
    @IBOutlet weak var tempoNovoTextView: UITextField!
    
    @IBOutlet weak var tempoNovoButao: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        nomeUsuario.text=Usuario.nomeUsuario
        
        usuarioImagem.image = UIImage(named: Usuario.imagemUsuario)
        
        numeroSessoesLabel.text = numeroToString(0)
        minutosSessaoLabel.text = numeroToString(Usuario.minutosPorSessao)
        focoTotalLabel.text = numeroToString(0)
        streakLabel.text = numeroToString(Usuario.streak)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        numeroSessoesLabel.text = numeroToString(Usuario.numeroSessoes)
        minutosSessaoLabel.text = numeroToString(Usuario.minutosPorSessao)
        focoTotalLabel.text = numeroToString(Usuario.minutosTotal)
        streakLabel.text = numeroToString(Usuario.streak)
    }
    
    func numeroToString(_ val:Int) -> String{
        return ("\(val)")
    }
    
    
    @IBAction func editarAction(_ sender: Any) {
        if(tempoNovoTextView.text != ""){
            minutosSessaoLabel.text = tempoNovoTextView.text
            
            var texto = minutosSessaoLabel.text
            Usuario.minutosPorSessao = (texto as! NSString).integerValue
            print("\(Usuario.minutosPorSessao)")
            tempoNovoTextView.text = ""
        }
    }
    
}
