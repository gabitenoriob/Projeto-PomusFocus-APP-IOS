//
//  StructTodo.swift
//  pomusFocus_PROJETO
//
//  Created by Student on 15/12/22.
//  Copyright © 2022 Student. All rights reserved.
//

import Foundation

struct myData {
    static var tasks = [String]()
}
