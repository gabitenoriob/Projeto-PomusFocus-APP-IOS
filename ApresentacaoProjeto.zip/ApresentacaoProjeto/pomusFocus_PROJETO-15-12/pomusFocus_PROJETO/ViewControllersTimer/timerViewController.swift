//
//  timerViewController.swift
//  pomusFocus_PROJETO
//
//  Created by Student on 10/12/22.
//  Copyright © 2022 Student. All rights reserved.
//

//https://www.youtube.com/watch?v=GzwLobVuXXI

import UIKit

class timerViewController: UIViewController {
    
    
    @IBOutlet weak var imagemStatus: UIImageView!
    
    @IBOutlet weak var tempoLabel: UILabel!
    @IBOutlet weak var startStopButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    
    
    
    var tempoContando:Bool = false
    var tempoIniciar:Date?
    var tempoParar:Date?
    
    /*var minutosFoco:Int = 1//1 = 2 min
    var segundosFoco:Int = 59
    var minutos:Int = 0
    
    var minDisplay:Int = 2 //minutosFoco + 1*/
    
    var minutosFoco:Int = 0
    var segundosFoco:Int = 0
    var minutos:Int = 0
    var minDisplay:Int = 0

    
    var imagems = ["tomato","plant","morta","pause"]
    
    var sessoes:Int = 0
    var minutosSessoes:Int = 0
    
    let userDefaults = UserDefaults.standard
    let INICIAR_TEMPO_KEY = "tempoIniciar"
    let PARAR_TEMPO_KEY = "tempoParar"
    let CONTANDO_KEY = "tempoContando"
    
        
    
    var tempoProgramado:Timer! //heduled timer - variavel para usar a lib Timer
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       print("DidLoad")
       
        
        
        
        //print("sessoes->\(sessoes) minutos estudados -> \(minutosSessoes)")
        
        imagemStatus.image = UIImage(named: imagems[0])
        tempoLabel.text = tempoToString(m: minDisplay, s: Usuario.minutosPorSessao)
        
        tempoIniciar = userDefaults.object(forKey: INICIAR_TEMPO_KEY) as? Date
        tempoParar = userDefaults.object(forKey: PARAR_TEMPO_KEY) as? Date
        tempoContando = userDefaults.bool(forKey: CONTANDO_KEY)
        
        if tempoContando{
            iniciarTimer()
        }else{
            pararTimer()
            if let inicio = tempoIniciar{
                if let parar = tempoParar{
                    let tempo = calcRestartTempo(inicio: inicio, fim: parar)
                    let diff = Date().timeIntervalSince(tempo)
                    setTempoLabel(Int(diff))
                }
            }
        }
        

    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        minDisplay = Usuario.minutosPorSessao
        minutosFoco = minDisplay - 1
        //tempoLabel.text = tempoToString(m: minDisplay, s: Usuario.minutosPorSessao)
    }
    
    @IBAction func startStopAction(_ sender: Any) {
        //print(3)
        if tempoContando { // quero parar
            
            setTempoParar(date: Date())
            pararTimer()
            
        }else{ //quero comecar
            if let parar = tempoParar{
                let restartTempo = calcRestartTempo(inicio:tempoIniciar!, fim:parar)
                setTempoParar(date: nil)
                setTempoIniciar(date: restartTempo)
            }else{
                setTempoIniciar(date: Date())
            }
            iniciarTimer()
        }
    }
    func calcRestartTempo(inicio: Date, fim:Date) -> Date{
        let diff = inicio.timeIntervalSince(fim)
        return Date().addingTimeInterval(diff)
    }
    
    func pararTimer(){
        
        if tempoProgramado != nil {
            tempoProgramado.invalidate()
        }
        setTempoContando(false)
        startStopButton.setTitle("START", for: .normal)
        startStopButton.setTitleColor(UIColor.black, for: .normal)
        
    
        
        let cond:Bool = (minutos==minutosFoco) && Usuario.reset == false
        print("->\(minutosFoco):\(segundosFoco) \(cond)")
        if(cond){
            sessoes = sessoes + 1
            minutosSessoes += minDisplay
            
            Usuario.numeroSessoes += 1
            Usuario.minutosTotal += Usuario.minutosPorSessao
            print("\(Usuario.numeroSessoes) \(Usuario.minutosTotal )")
            
            print("sessoes->\(sessoes) minutos estudados -> \(minutosSessoes)")
            imagemStatus.image = UIImage(named: imagems[0])
        }else{
            imagemStatus.image = UIImage(named: imagems[2])
        }
        
        //resetar
        
        setTempoParar(date: nil)
        setTempoIniciar(date: nil)
        
        
        
    }
    func iniciarTimer(){
        tempoProgramado = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(refreshTempo), userInfo: nil, repeats: true)
        
        imagemStatus.image = UIImage(named: imagems[1])
        
        setTempoContando(true)
        startStopButton.setTitle("PARAR", for: .normal)
        startStopButton.setTitleColor(UIColor.red, for: .normal)
        Usuario.reset = false
    }
    
    @objc func refreshTempo(){
        if let inicio = tempoIniciar{
            let diff = Date().timeIntervalSince(inicio)
            print(Int(diff))
            setTempoLabel(Int(diff))
        }else{
            pararTimer()
            setTempoLabel(0)
        }
    }
    func setTempoLabel(_ val: Int){
        
        let tempo = secsToHorasMinutosSecs(val)
        
        minutos = tempo.1
        var minutosPassados = abs(minutosFoco - minutos)
        
        var segundos = 59 - tempo.2
        
        segundosFoco = segundos
        
        let texto = tempoToString(m: minutosPassados, s: segundos)
        
        tempoLabel.text = texto
        
        if(minutosFoco==minutos && segundosFoco==0){
            pararTimer()
            //setTempoContando(false)
        }
        
        print("\(minutosFoco):\(segundosFoco) minutos passados:\(minutosPassados)")
    }
    
    func secsToHorasMinutosSecs(_ ms: Int) -> (Int, Int, Int){
        let horas = ms / 3600
        let minutos = (ms % 3600) / 60
        let segundos = (ms % 3600) % 60
        return (horas, minutos, segundos)
    }
    
    func tempoToString(m: Int, s:Int) -> String{
        var tempoString = ""
        tempoString += String(format: "%02d", m)
        tempoString+=":"
        tempoString += String(format: "%02d", s)
        return tempoString
    }
    
    @IBAction func resetAction(_ sender: Any) {
        Usuario.reset = true
        setTempoParar(date: nil)
        setTempoIniciar(date: nil)
        tempoLabel.text = tempoToString(m: minDisplay, s: 0)
        pararTimer()
        imagemStatus.image = UIImage(named: imagems[0])
    }
    
    func setTempoIniciar(date:Date?){
        tempoIniciar = date
        userDefaults.set(tempoIniciar, forKey: INICIAR_TEMPO_KEY)
    }
    func setTempoParar(date:Date?){
        tempoParar = date
        userDefaults.set(tempoParar, forKey: PARAR_TEMPO_KEY)
    }
    func setTempoContando(_ val:Bool){
        tempoContando = val
        userDefaults.set(tempoContando, forKey: CONTANDO_KEY)
    }
    
}
